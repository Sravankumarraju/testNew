// function getEmpData() {
//     var empData = [];
//     let status = "";
//     let endDate = "";
//     $.ajax({
//         // url: "http://192.168.30.155:5000/allemployees",
//         url : "https://rre-api.factspanapps.com:5000/allemployees",
//         type: "POST",
//         dataType: "json",
//         crossDomain: true,
//         format: "json",
//         async: false,
//         success:function(json){
//             jsonData = json
//             empData = jsonData.data.EMPLOYEE_DETAILS.DETAILS;
//             //console.log("jsonData  - ",empData);
//             for (var i=0; i<empData.length; i++) {
//                 if(empData[i].FLAG == 1){
//                     status = "Active";
//                 }else{
//                     status = "Inactive";
//                 }
//                 if(empData[i].END_DATE == "0000-00-00"){
//                     endDate = "";
//                 }else{
//                     endDate = convert(empData[i].END_DATE);
//                 }
//                 var row = $('<tr><td>' + empData[i].EMPLOYEE_ID+ '</td><td>' + 
//                 empData[i].EMPLOYEE_NAME + '</td><td>' + 
//                 empData[i].DESIGNATION + '</td><td>' + 
//                 convert(empData[i].JOIN_DATE) + '</td><td>' + 
//                 endDate + '</td><td>' + 
//                 empData[i].LOCATION_ + '</td><td>' + 
//                 empData[i].FUNCTION_ + '</td><td><span class="'+status.toLowerCase()+'">' + 
//                 status + '</span></td><td><button class="btn btn-info" id="employee_full_details" style="margin: 10px;" onclick="employeeDetails()">View All</button></td></tr>');
//                 $('#emp_table').append(row);
//             }
//             //console.log("EMP data - ",row);
//         },
//         error:function(error){
//             console.log('message Error' + JSON.stringify(error));
//         }  
//     });  
// }

function getEmpData() {
    var empData = [];
    let status = "";
    let endDate = "";
    $.ajax({
        url: "https://rre-api.factspanapps.com:5000/app",
        // url : "http://localhost:5770/app",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        async: false,
        mode: 'no-cors',
        data : {
            query_type : "select",
            db_name : "rre_db",
            table_name : "EMPLOYEE_MASTER_VIEW",
            columns : "",
            filter : ""
        },
        success:function(data){
            jsonData = data
            empData = jsonData.data.Details;
            console.log("jsonData  - ",empData);
            for (var i=0; i<empData.length; i++) {
                if(empData[i].END_DATE == "0000-00-00"){
                    endDate = "";
                }else{
                    endDate = convert(empData[i].END_DATE);
                }
                var row = $('<tr><td>' + empData[i].EMPLOYEE_ID+ '</td><td>' + 
                empData[i].EMPLOYEE_NAME + '</td><td>' + 
                empData[i].JOB_ROLE_ID + '</td><td>' + 
                convert(empData[i].JOIN_DATE) + '</td><td>' + 
                endDate + '</td><td>' + 
                empData[i].LOCATION+ '</td><td>' + 
                empData[i].FUNCTION + '</td><td><span class="'+empData[i].STATUS.toLowerCase()+'">' + 
                empData[i].STATUS + '</span></td><td><button class="btn btn-info" id="employee_full_details" style="margin: 10px;" onclick="getEmpProfileData(this)">View All</button></td></tr>');
                $('#emp_table').append(row);
            }
            console.log("EMP data - ",row);
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
        }  
    });  
}

function getEmpProfileData(obj) {
    var employee_id = $(obj).closest('tr').children('td:eq(0)').text();
    console.log("employee_id - "+employee_id);
    var empDataProfile = [];
    let endDate = "";
    var local_emp_profile_data = "";
    $("body").addClass("loading"); 
    $.ajax({
        url: "https://rre-api.factspanapps.com:5000/app",
        // url : "http://localhost:5770/app",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        async: false,
        mode: 'no-cors',
        // headers: {
        //     "accept": "application/json",
        //     "Access-Control-Allow-Origin":"*"
        // },
        data : {
            query_type : "select",
            db_name : "rre_db",
            table_name : "EMPLOYEE_MASTER_VIEW",
            columns : "",
            filter : "EMPLOYEE_ID = '"+employee_id+"'"
        },
        // data: JSON.stringify({query_type:'select',db_name: 'rre_db',table_name:'EMPLOYEE_MASTER_VIEW',columns:'',filter:''}),
        // data: "{'query_type':'select','db_name': 'rre_db','table_name':'EMPLOYEE_MASTER_VIEW','columns':'','filter':''}",
        success:function(data){
            jsonData = data
            empDataProfile = jsonData.data.Details;
            console.log("Emp Profile - ",empDataProfile);
            if (typeof(Storage) !== "undefined") {
                // Store
                localStorage.setItem("emp_profile_id_data", JSON.stringify(empDataProfile));
                localStorage.setItem("employee_id_data", employee_id);
                // Retrieve
                local_emp_profile_data = localStorage.getItem("emp_profile_id_data");
            } else {
            document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Storage...";
            }
            console.log("local_emp_profile_data - ",local_emp_profile_data);
            window.location.href = 'employee_profile.html';
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
        }  
    });  
}

function convert(str) {
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }
  console.log(convert("Mon, 11 Nov 2013 00:00:00 GMT"))

// Add remove loading class on body element depending on Ajax request status
$(document).on({
    ajaxStart: function(){
        $("body").addClass("loading"); 
        console.log("On");
    },
    ajaxStop: function(){ 
        $("body").removeClass("loading"); 
        console.log("Off");
    }    
});