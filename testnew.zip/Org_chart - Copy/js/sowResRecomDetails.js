function getEmpNameOptions() {
    var empData = [];
    let status = "";
    let endDate = "";
    $.ajax({
        // url: "https://rre-api.factspanapps.com:5000/app",
        url : "http://localhost:5770/app",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        async: false,
        mode: 'no-cors',
        data : {
            query_type:"resource_available"
        },
        success:function(data){
            jsonData = data
            console.log("jsonData - ",jsonData);
            data = jsonData.data.Available_Resources ;
            console.log("SOW_RESOURCE_ALLOCATION_SUMMARY - ",data);
               for (var i = 0; i < data.length; i++) {  
                emp_options += '<option value="' + data[i].EMPLOYEE_NAME + '">' + data[i].EMPLOYEE_NAME + '</option>';  
               }  
              //  $(".emp_names").html(emp_options); 
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
        }  
    });  
  }

  