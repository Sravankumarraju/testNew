
function createSowResReq(){
    let sow_code = $("#sow_code").val();
    let sow_name = $("#sow_name").val();
    let account = $("#account").val();
    let legal_start_date = $("#legal_start_date").val();
    let legal_end_date = $("#legal_end_date").val();
    let total_resources = $("#total_resources").val();
    let onsite_resource = $("#onsite_resource").val();
    let offshore_resource = $("#offshore_resource").val();
    let probability = $("#probability").val();
    
    var table = $("#sow_res_recom_table_data tbody");
    let sow_skills = "";
    table.find('tr').each(function (i) {
        var $tds = $(this).find('td'),
            Resource = $tds.eq(0).text(),
            mhs_1 = $tds.eq(1).find(":selected").val(),
            level_mhs_1 = $tds.eq(2).find(":selected").val(),
            mhs_2 = $tds.eq(3).find(":selected").val(),
            level_mhs_2 = $tds.eq(4).find(":selected").val(),
            mhs_3 = $tds.eq(5).find(":selected").val(),
            level_mhs_3 = $tds.eq(6).find(":selected").val(),
            mhs_4 = $tds.eq(7).find(":selected").val(),
            level_mhs_4 = $tds.eq(8).find(":selected").val(),
            mhs_5 = $tds.eq(9).find(":selected").val(),
            level_mhs_5 = $tds.eq(10).find(":selected").val();
            mhs_6 = $tds.eq(11).find(":selected").val(),
            level_mhs_6 = $tds.eq(12).find(":selected").val();
            mhs_7 = $tds.eq(13).find(":selected").val(),
            level_mhs_7 = $tds.eq(14).find(":selected").val();
            mhs_8 = $tds.eq(15).find(":selected").val(),
            level_mhs_8 = $tds.eq(16).find(":selected").val();
            mhs_9 = $tds.eq(17).find(":selected").val(),
            level_mhs_9 = $tds.eq(18).find(":selected").val();
            mhs_10 = $tds.eq(19).find(":selected").val(),
            level_mhs_10 = $tds.eq(20).find(":selected").val();
        // do something with productId, product, Quantity
        sow_skills = sow_skills + "{\"Resource\":\""+Resource+
                                    "\",\"MUST_HAVE_SKILL_ID_1\":\""+mhs_1+
                                    "\",\"MUST_HAVE_LEVEL_ID_1\": \""+level_mhs_1+
                                    "\",\"MUST_HAVE_SKILL_ID_2\": \""+mhs_2+
                                    "\",\"MUST_HAVE_LEVEL_ID_2\": \""+level_mhs_2+
                                    "\",\"MUST_HAVE_SKILL_ID_3\": \""+mhs_3+
                                    "\",\"MUST_HAVE_LEVEL_ID_3\": \""+level_mhs_3+
                                    "\",\"MUST_HAVE_SKILL_ID_4\": \""+mhs_4+
                                    "\",\"MUST_HAVE_LEVEL_ID_4\": \""+level_mhs_4+
                                    "\",\"MUST_HAVE_SKILL_ID_5\": \""+mhs_5+
                                    "\",\"MUST_HAVE_LEVEL_ID_5\": \""+level_mhs_5+
                                    "\",\"GOOD_TO_HAVE_SKILL_ID_1\": \""+mhs_6+
                                    "\",\"GOOD_TO_HAVE_LEVEL_ID_1\": \""+level_mhs_6+
                                    "\",\"GOOD_TO_HAVE_SKILL_ID_2\": \""+mhs_7+
                                    "\",\"GOOD_TO_HAVE_LEVEL_ID_2\": \""+level_mhs_7+
                                    "\",\"GOOD_TO_HAVE_SKILL_ID_3\": \""+mhs_8+
                                    "\",\"GOOD_TO_HAVE_LEVEL_ID_3\": \""+level_mhs_8+
                                    "\",\"GOOD_TO_HAVE_SKILL_ID_4\": \""+mhs_9+
                                    "\",\"GOOD_TO_HAVE_LEVEL_ID_4\": \""+level_mhs_9+
                                    "\",\"GOOD_TO_HAVE_SKILL_ID_5\": \""+mhs_10+
                                    "\",\"GOOD_TO_HAVE_LEVEL_ID_5\": \""+level_mhs_10+
                                "\"},"
    });
    if (sow_skills.endsWith(",")){
        sow_skills = sow_skills.slice(0, -1);
    }
    //console.log("sow_skills - "+sow_skills);

    // var sowData = {
    //     "query_type": "insert_sow",
    //     "insert_skills": "["+sow_skills+"]",
    //     "insert_sow": "[{'SOW_CODE':\"" +sow_code+
    //                 "\",\"SOW_NAME\": \""+sow_name+
    //                 "\",\"ACCOUNT\": \""+account+
    //                 "\",\"LEGAL_START_DATE\": \""+legal_start_date+
    //                 "\",\"LEGAL_END_DATE\": \""+legal_end_date+
    //                 "\",\"ONSITE_RESOURCES\": \""+onsite_resource+
    //                 "\",\"OFFSHORE_RESOURCES\": \""+offshore_resource+
    //                 "\",\"TOTAL_RESOURCES\": \""+total_resources+
    //                 "\",\"PROBABILITY\": \""+probability+
    //                 "\"}]"
    // }    
    // console.log("sowData - ",sowData);
    // var insert_sow_data = [
    //     {
    //         SOW_CODE : "'"+sow_code+"'",
    //         SOW_NAME : "'"+sow_name+"'",
    //         ACCOUNT : "'"+account+"'",
    //         LEGAL_START_DATE : "'"+legal_start_date+"'",
    //         LEGAL_END_DATE : "'"+legal_end_date+"'",
    //         ONSITE_RESOURCES : "'"+onsite_resource+"'",
    //         OFFSHORE_RESOURCES : "'"+offshore_resource+"'",
    //         TOTAL_RESOURCES : "'"+total_resources+"'",
    //         PROBABILITY : "'"+probability+"'"
    //     }
    // ]

    $.ajax({
        url: "https://rre-api.factspanapps.com:5000/app",
        // url : "http://localhost:5770/app",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        async: false,
        mode: 'no-cors',
        data : {
            query_type : "insert_sow",
            insert_skills : "["+ sow_skills +"]",
            insert_sow : "[{'SOW_CODE':'" +sow_code+
            "','SOW_NAME': '"+sow_name+
            "', 'ACCOUNT': '"+account+
            "', 'LEGAL_START_DATE': '"+legal_start_date+
            "', 'LEGAL_END_DATE': '"+legal_end_date+
            "', 'ONSITE_RESOURCES': '"+onsite_resource+
            "', 'OFFSHORE_RESOURCES': '"+offshore_resource+
            "', 'TOTAL_RESOURCES': '"+total_resources+
            "', 'PROBABILITY': '"+probability+
            "'}]",
            db_name:"DEVELOP_DB"
        },
        success:function(data){
            jsonData = data
            console.log("jsonData - ",jsonData);
            window.location.href = 'sowDetails.html';
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
        }  
    }); 
    
}

