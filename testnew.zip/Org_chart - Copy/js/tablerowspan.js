var data = 
`{
    "result":
    {
        " ":[
                {
                    "":
                        [
                            "Utilization % (Delivery-IND)",
                            "Total IND Utilization %", 
                            "IND OPEN Reqs - Delivery",
                            "IND OPEN Reqs - Non-Delivery"
                        ]
                }
            ],
        "":[
                {
                    "Available":
                        [
                            "Total Available Resource Count",
                            "Training", 
                            "Factspan Product",
                            "Actual Bench",
                            "Usable Bench",
                            "Special Leaves"
                        ]
                }
            ], 
        "IND":[
                {
                    "Demand":
                        [
                            "Signed SOW",
                            "70% Probability",
                            "50% Probability"
                        ]
                },
                {
                    "Supply":
                        [
                            "Actual Delivery Head Count",
                            "Projected Delivery Head Count (Includes Resigned Folks, Proj. Attr. and New Joinees)",
                            "Resigned Folks",
                            "Proj. New Joinees (Offered Folks)",
                            "Proj. Attr."
                        ]
                },
                {
                    "GAP":
                        [
                            "Proj. Delivery Head Count",
                            "Signed SOW",
                            "70% Probability",
                            "50% Probability",
                            "Actual Delivery Head Count",
                            "Signed SOW",
                            "70% Probability",
                            "50% Probability"
                        ]
                }
            ], 
        "Offshore":[
                        {
                            "All":
                                [
                                    "No. of Client SOWs",
                                    "No. of Internal Project SOWs", 
                                    "SOW Resource Billed",
                                    "Client Resource #",
                                    "Actual Billed",
                                    "Investment",
                                    "Buffer",
                                    "Leaders Investment",
                                    "Total Available Resource Count",
                                    "Training",
                                    "Factspan Product",
                                    "Actual Bench",
                                    "Usable Bench",
                                    "Special Leaves"
                                ]
                        }
                    ],
        "Actual":[
                {
                    "":
                        [
                            "Total Delivery Headcount"
                        ]
                }
            ]
    },
    "Build sets":"type","destinationPath":"client","status":1}`;

function generateTable(data) { //data is the parsed JSON Object from an ajax request
  data = JSON.parse(data);
  $("#sow_rsrc_all_sum_table tbody").empty(); //Empty the table first
  Object.entries(data.result).forEach(([key, elem]) => {
    var baseHtml = "";
    var childrenHtml = "";
    var maxRowSpan = 0;
    elem.forEach((inner_elem, index) => {
      var [innerElemKey, arr] = Object.entries(inner_elem)[0];
      var elemRowSpan = Math.max(arr.length, 1);
      maxRowSpan += elemRowSpan;

      if (index !== 0) {
        childrenHtml += "<tr>";
      } 
      childrenHtml += ('<td rowspan="' + elemRowSpan + '">' + innerElemKey + '</td>');
      
      arr.forEach((child, indx) => {
        if (indx !== 0) {
          childrenHtml += "</tr>";
        }
        childrenHtml += ('<td rowspan="1">' + child + '</td>' + '</tr>');
      });
    });
    baseHtml += ('<tr><td rowspan="' + Math.max(maxRowSpan, 1) + '">' + key + '</td>');
    $("#sow_rsrc_all_sum_table").append(baseHtml + childrenHtml);
  });
}

$(function() {
  generateTable(data);
});