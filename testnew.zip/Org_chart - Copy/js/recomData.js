function getRecomData() {
    // var recomData = [];
    // $.ajax({
    //     // url: "http://192.168.30.155:5000/recommend",
    //     url : "https://rre-api.factspanapps.com:5000/recommend",
    //     type: "POST",
    //     dataType: "json",
    //     crossDomain: true,
    //     format: "json",
    //     async: false,
    //     success:function(json){
    //         jsonData = json
    //         recomData = jsonData.data.RECOMMENDATION.REC_STRUCTURE;
    //         console.log("jsonData  - ",jsonData.data.RECOMMENDATION.REC_STRUCTURE);
    //         for (var i=0; i<recomData.length; i++) {
    //             var row = $('<tr><td>' + recomData[i].SOW_ID+ '</td><td>' + 
    //             recomData[i].Resource_Count + '</td><td>' + 
    //             recomData[i].Associate + '</td><td>' + 
    //             recomData[i].Analyst + '</td><td>' + 
    //             recomData[i].Senior_Analyst + '</td><td>' + 
    //             recomData[i].Associate_Manager + '</td><td>' + 
    //             recomData[i].Manager_ + '</td><td>' + 
    //             recomData[i].Solution_Architect + '</td><td><button type="button" class="btn view_detail btn-default pull-right hit" onclick="sowResData(this)">View Details</button></td></tr>');
    //             $('#sow_res_recom_table_data').append(row);
    //         }
            
    //     },
    //     error:function(error){
    //         console.log('message Error' + JSON.stringify(error));
    //     }  
    // });  
    var recomJsonData = [];
    let status = "";
    let endDate = "";
    $.ajax({
        url : "https://rre-api.factspanapps.com:5000/app",
        // url: "http://localhost:5770/app",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        async: false,
        mode: 'no-cors',
        data : {
            "query_type":"select",
            "db_name": "rre_db",
            "table_name":"SOW_RESOURCE_TEAM_VIEW",
            "columns":"",
            "filter":""
        },
        success:function(data){
            jsonData = data
            recomJsonData = jsonData.data.Details;
            console.log("jsonData  - ",recomJsonData);
            for (var i=0; i<recomJsonData.length; i++) {
                var row = $('<tr><td>' + recomJsonData[i].SOW_ID+ '</td><td>' + 
                recomJsonData[i].TOTAL_RESOURCES + '</td><td>' + 
                recomJsonData[i].Associate_ + '</td><td>' + 
                recomJsonData[i].Analyst_ + '</td><td>' + 
                recomJsonData[i].Sr_Analyst_ + '</td><td>' + 
                recomJsonData[i].AM_ + '</td><td>' + 
                recomJsonData[i].M_ + '</td><td>' + 
                recomJsonData[i].Soln_Arch + '</td><td><button type="button" class="btn view_detail btn-default pull-right hit" onclick="sowResData(this)">View Details</button></td></tr>');
                $('#sow_res_recom_table_data').append(row);
            }
            console.log("EMP data - ",row);
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
        }  
    }); 
}

function sowResData(obj) {
    var sow_id = $(obj).closest('tr').children('td:eq(0)').text();
    var Resource_count = $(obj).closest('tr').children('td:eq(1)').text();
    console.log("sow_id - "+sow_id);
    console.log("Resource_count - "+Resource_count);
    // var analyst = $(obj).closest('tr').children('td:eq(3)').text();
    // var sranalyst = $(obj).closest('tr').children('td:eq(4)').text();
    //console.log("sow_id - "+sow_id);
    //console.log("Resource_count - "+Resource_count);
    var sow_recom_id = [];
    var local_sow_recom_data = [];
    $.ajax({
        
        url : "https://rre-api.factspanapps.com:5000/app",
        // url: "http://localhost:5770/app",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        async: false,
        mode: 'no-cors',
        data : {
            // query_type:"recommend",
            query_type:"view_all",
            // TOTAL_RESOURCES: Resource_count,
            SOW_ID:sow_id
        },
        success:function(data){
            jsonData = data
            console.log("jsonData - ",jsonData);
            recomJsonData = jsonData.data.Recommended_Employees;
            console.log("recomJsonData - ",recomJsonData);
            if (typeof(Storage) !== "undefined") {
                // Store
                localStorage.setItem("sow_recom_profile_id_data", JSON.stringify(recomJsonData));
                localStorage.setItem("sow_recom_id_data", sow_id);
                // Retrieve
                // local_sow_recom_profile_id_data = localStorage.getItem("sow_recom_profile_id_data");
                // local_sow_recom_id_data = localStorage.getItem("sow_recom_id_data");
            } else {
            document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Storage...";
            }
            // console.log("local_sow_recom_profile_data - ",local_sow_recom_profile_id_data);
            window.location.href = 'sowResRecomDetails.html';
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
        }  
    });
}



