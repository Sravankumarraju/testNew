// Get date and time function

function getDateTime() {
    var today = new Date();
    var day = today.getDate() + "";
    var month = (today.getMonth() + 1) + "";
    var year = today.getFullYear() + "";
    var hour = today.getHours() + "";
    var minutes = today.getMinutes() + "";
    var seconds = today.getSeconds() + "";

    day = checkZero(day);
    month = checkZero(month);
    year = checkZero(year);
    hour = checkZero(hour);
    minutes = checkZero(minutes);
    seconds = checkZero(seconds);

    //let dateTime = day + "-" + month + "-" + year + " " + hour + ":" + minutes + ":" + seconds
    let dateTime = day + "-" + month + "-" + year;

    //console.log("dateTime - "+dateTime);

    function checkZero(data) {
        if (data.length == 1) {
            data = "0" + data;
        }
        return data;
    }

    return dateTime;
}
var jsonData = [];
var importedEmpList = [];
var existingEmpList = [];
var revertChanges = [];

/* Loading org chart data on page load */

jQuery(document).ready(function() {
    //getDateTime();
    $("#show-list").click(function(e) {
        e.preventDefault();

        $("#list-html").toggle("fast", function() {
            if ($(this).is(":visible")) {
                $("#show-list").text("Hide underlying list.");
                $(".topbar").fadeTo("fast", 0.9);
            } else {
                $("#show-list").text("Show underlying list.");
                $(".topbar").fadeTo("fast", 1);
            }
        });
    });

    $("#list-html").text($("#org").html());

    $("#org").bind("DOMSubtreeModified", function() {
        $("#list-html").text("");

        $("#list-html").text($("#org").html());

        prettyPrint();
    });

    getData();
    
    // loadChart('Org Chart');
    // $("#Org_Chart").addClass("active");
    // console.log("Size - "+$(".jOrgChart").size());
});
//var scenario_name_list = [];
function employee_chart_data() {
    $.ajax({
        // url: "http://127.0.0.1:5000/allscenarios?user=206",
        // url: "http://192.168.30.155:5000/allscenarios?user=1486",
        // url : "https://rre-api.factspanapps.com:5000/allscenarios?user=1486",
        // type: "POST",
        // dataType: "json",
        // crossDomain: true,
        // format: "json",
        // async: false,
        // url: "http://localhost:5770/app",
        url: "https://rre-api.factspanapps.com:5000/app",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        async: false,
        mode: 'no-cors',
        data : {
            "query_type":"ALL_SCENARIO",
            "user": "0002"
        
        }
        ,
        success:function(json){
            $('#org_chart_select').empty();
            //console.log('message: ' + "success"+ JSON.stringify(json)); 
            jsonData = json
            console.log("jsonData scenario - ",jsonData.data);
            //console.log("Json SIze - ",Object.keys(jsonData.data).length)
            //jsonData.forEach(scr => {
                var id = jsonData.data.DEFAULT.SCENARIO_NAME.replace(" ","_");
                //console.log("id new - "+id);
                $("#mySidenav").append("<a id="+id+" onClick='loadChart(\""+jsonData.data.DEFAULT.SCENARIO_NAME.trim()+"\")'><img id='"+id+"_img' src='images\\organization-chart_icon.png' alt='Org Chart Icon' width='20' height='25' ><img id='"+id+"_img' src='images\\organization-chart_hover.png' alt='Org Chart Icon' width='20' height='25' > "+jsonData.data.DEFAULT.SCENARIO_NAME+"</a>");
                $('#org_chart_select').append("<option id="+id+" onchange='loadChart(\""+jsonData.data.DEFAULT.SCENARIO_NAME.trim()+"\")' value="+jsonData.data.DEFAULT.SCENARIO_NAME+" >"+jsonData.data.DEFAULT.SCENARIO_NAME+"</option>");
                if(Object.keys(jsonData.data).length > 1){
                    //var id = jsonData.data.SAVED.SCENARIO_NAME.replace(" ","_");
                    scenario_list = jsonData.data.SAVED;
                    //console.log("scenario_list - ",scenario_list);
                    //console.log("jsonData.data.SAVED.SCENARIO_NAME - ",jsonData.data.SAVED.SCENARIO_NAME);
                    scenario_list.forEach(scr => {
                        // console.log("scr - ",scr);
                        // console.log("scr.SCENARIO_NAME - ",scr.SCENARIO_NAME);
                        var id = scr.SCENARIO_NAME.replace(" ","_");
                        $("#mySidenav").append("<a id="+id+" onClick='loadChart(\""+scr.SCENARIO_NAME.trim()+"\")'><img id='"+id+"_img' src='images\\scenario_icon.png' alt='Org Chart Icon' width='20' height='25'><img id='"+id+"_img' src='images\\scenario_icon_hover.png' alt='Org Chart Icon' width='20' height='25'> "+scr.SCENARIO_NAME+"</a>");
                        $('#org_chart_select').append("<option id="+id+" onchange='loadChart(\""+scr.SCENARIO_NAME.trim()+"\")' value="+scr.SCENARIO_NAME.trim()+">"+scr.SCENARIO_NAME.trim()+"</option>");
                    });
                    
                }
            //});
            loadChart("Org Chart");
            $("#Org_Chart").addClass("active");
            $('#Org_Chart_img').attr('src', 'images\\organization-chart_hover.png');
            // console.log("Size - "+$(".jOrgChart").size());

            var org = [];
            org = jsonData.data;
            // console.log("org - ",org);
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
        }  
    }); 
}
var scenario_list = [];
function getData() {
    let serialNum = 1;
    $("#mySidenav").html('');
    //alert($("#org_chart_type").val());
    var val = $("#org_chart_type").val();
    employee_chart_data();
    $("#org_chart_type").change(function () {
        val = $(this).val();
        if (val == "Employee Chart") {
            //alert("Employee");
            employee_chart_data();
        }else if(val == "SOW Chart"){
            //alert("SOW Chart");
            jsonData =[
                {
                    "scenario":"SOW Chart",
                    "created_by": 206,
                    "create_time":"02 / 06 / 2021 15: 56: 29",
                    "org_structure":[
                    // {
                    //     "empID":999, //SOW_ID
                    //     "empName":"Factspan", //SOW_Name
                    //     "empDesg":"Owner",
                    //     "repMangId":0, //Client_ID
                    //     "repMangName":"" //Client_name
                    // },
                    {
                        "empID":1,
                        "empName":"Factspan",
                        "empDesg":"",
                        "repMangId":0,
                        "repMangName":""
                    },
                    {
                        "empID":101,
                        "empName":"ACI",
                        "empDesg":"Active",
                        "repMangId":1,
                        "repMangName":"Factspan"
                    },
                    {
                        "empID":102,
                        "empName":"Albertsons",
                        "empDesg":"Active",
                        "repMangId":1,
                        "repMangName":"Factspan"
                    },
                    {
                        "empID":103,
                        "empName":"Anthem",
                        "empDesg":"Active",
                        "repMangId":1,
                        "repMangName":"Factspan"
                    },
                    {
                        "empID":104,
                        "empName":"Disney",
                        "empDesg":"Active",
                        "repMangId":1,
                        "repMangName":"Factspan"
                    },
                    {
                        "empID":105,
                        "empName":"HCA",
                        "empDesg":"Active",
                        "repMangId":1,
                        "repMangName":"Factspan"
                    },
                    {
                        "empID":106,
                        "empName":"LeadVenture",
                        "empDesg":"Active",
                        "repMangId":1,
                        "repMangName":"Factspan"
                    },
                    {
                        "empID":107,
                        "empName":"LifeLock",
                        "empDesg":"Active",
                        "repMangId":1,
                        "repMangName":"Factspan"
                    },
                    {
                        "empID":108,
                        "empName":"Macys",
                        "empDesg":"Active",
                        "repMangId":1,
                        "repMangName":"Factspan"
                    },
                    {
                        "empID":1001,
                        "empName":"Fraud",
                        "empDesg":"Active",
                        "repMangId":101,
                        "repMangName":"ACI"
                    },
                    {
                        "empID":1002,
                        "empName":"NLP-Pilot",
                        "empDesg":"Active",
                        "repMangId":101,
                        "repMangName":"ACI"
                    },
                    {
                        "empID":2001,
                        "empName":"Fulfillment - May",
                        "empDesg":"Active",
                        "repMangId":102,
                        "repMangName":"Albertsons"
                    },
                    {
                        "empID":2002,
                        "empName":"Loyalty Analytics",
                        "empDesg":"Active",
                        "repMangId":102,
                        "repMangName":"Albertsons"
                    },
                    {
                        "empID":2003,
                        "empName":"Marketing",
                        "empDesg":"Planned",
                        "repMangId":102,
                        "repMangName":"Albertsons"
                    },
                    {
                        "empID":2004,
                        "empName":"Merch - Terry",
                        "empDesg":"Active",
                        "repMangId":102,
                        "repMangName":"Albertsons"
                    },
                    {
                        "empID":3001,
                        "empName":"Sanjay",
                        "empDesg":"Active",
                        "repMangId":103,
                        "repMangName":"Anthem"
                    },
                    {
                        "empID":4001,
                        "empName":"Brian Engagements",
                        "empDesg":"Active",
                        "repMangId":104,
                        "repMangName":"Disney"
                    },
                    {
                        "empID":4002,
                        "empName":"Brian - Sustainment",
                        "empDesg":"Active",
                        "repMangId":104,
                        "repMangName":"Disney"
                    },
                    {
                        "empID":4003,
                        "empName":"DCLRMS",
                        "empDesg":"Active",
                        "repMangId":104,
                        "repMangName":"Disney"
                    },
                    {
                        "empID":4004,
                        "empName":"DLP",
                        "empDesg":"Active",
                        "repMangId":104,
                        "repMangName":"Disney"
                    },
                    {
                        "empID":4005,
                        "empName":"Sustainment",
                        "empDesg":"Active",
                        "repMangId":104,
                        "repMangName":"Disney"
                    },
                    {
                        "empID":4006,
                        "empName":"Suresh's Engagement",
                        "empDesg":"Active",
                        "repMangId":104,
                        "repMangName":"Disney"
                    },
                    {
                        "empID":5001,
                        "empName":"DE & Reporting",
                        "empDesg":"Active",
                        "repMangId":105,
                        "repMangName":"HCA"
                    },
                    {
                        "empID":5002,
                        "empName":"Salesforce",
                        "empDesg":"Active",
                        "repMangId":105,
                        "repMangName":"HCA"
                    },
                    {
                        "empID":6001,
                        "empName":"Data Lake",
                        "empDesg":"Active",
                        "repMangId":106,
                        "repMangName":"LeadVenture"
                    },
                    {
                        "empID":7001,
                        "empName":"Marketing Analytics",
                        "empDesg":"Active",
                        "repMangId":107,
                        "repMangName":"LifeLock"
                    },
                    {
                        "empID":8001,
                        "empName":"Data Governance - (Yannique)",
                        "empDesg":"Active",
                        "repMangId":108,
                        "repMangName":"Macys"
                    },
                    {
                        "empID":8002,
                        "empName":"System Analyst - (Raadika)",
                        "empDesg":"Active",
                        "repMangId":108,
                        "repMangName":"Macys"
                    },
                    {
                        "empID":8003,
                        "empName":"Marketing Systems",
                        "empDesg":"Active",
                        "repMangId":108,
                        "repMangName":"Macys"
                    },
                    {
                        "empID":8004,
                        "empName":"Product Analytics",
                        "empDesg":"Active",
                        "repMangId":108,
                        "repMangName":"Macys"
                    },//Employee details start
                    {
                        "empID":123,
                        "empName":"Wahengbam Paramjit Singh",
                        "empDesg":"M",
                        "repMangId":1001,
                        "repMangName":"Fraud"
                    },
                    {
                        "empID":156,
                        "empName":"Adhithya Karthikeyan",
                        "empDesg":"BA",
                        "repMangId":123,
                        "repMangName":"Wahengbam Paramjit Singh"
                    },
                    {
                        "empID":173,
                        "empName":"Selvaraj Sebastian Srikanth Kumar",
                        "empDesg":"BA",
                        "repMangId":123,
                        "repMangName":"Wahengbam Paramjit Singh"
                    },
                    {
                        "empID":333,
                        "empName":"Sravan Kumar Raju",
                        "empDesg":"C",
                        "repMangId":123,
                        "repMangName":"Wahengbam Paramjit Singh"
                    },
                    {
                        "empID":10,
                        "empName":"Ravikumar Rachuri",
                        "empDesg":"M",
                        "repMangId":1002,
                        "repMangName":"NLP-Pilot"
                    },
                    {
                        "empID":146,
                        "empName":"Krishika Ramaswamy",
                        "empDesg":"BA",
                        "repMangId":10,
                        "repMangName":"Ravikumar Rachuri"
                    },
                    {
                        "empID":151,
                        "empName":"Saheer Md",
                        "empDesg":"BA",
                        "repMangId":10,
                        "repMangName":"Ravikumar Rachuri"
                    },
                    {
                        "empID":221,
                        "empName":"Harsh Saraf",
                        "empDesg":"C",
                        "repMangId":10,
                        "repMangName":"Ravikumar Rachuri"
                    }
                    ]
                // },
                // {
                //     "scenario":"Scenario 1",
                //     "created_by": 206,
                //     "create_time":"02 / 06 / 2021 15: 56: 29",
                //     "org_structure":[
                //     {
                //         "empID":206,
                //         "empName":"Suresh Sayammagaru 1",
                //         "empDesg":"VP",
                //         "repMangId":0,
                //         "repMangName":""
                //     },
                //     {
                //         "empID":123,
                //         "empName":"Wahengbam Paramjit Singh",
                //         "empDesg":"M",
                //         "repMangId":206,
                //         "repMangName":"Suresh Sayammagaru"
                //     },
                //     {
                //         "empID":156,
                //         "empName":"Adhithya Karthikeyan",
                //         "empDesg":"BA",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     },
                //     {
                //         "empID":173,
                //         "empName":"Selvaraj Sebastian Srikanth Kumar",
                //         "empDesg":"BA",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     },
                //     {
                //         "empID":333,
                //         "empName":"Sravan Kumar Raju",
                //         "empDesg":"C",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     }
                //     ]
                // },
                // {
                //     "scenario":"Scenario 2",
                //     "created_by": 206,
                //     "create_time":"02 / 06 / 2021 15: 56: 29",
                //     "org_structure":[
                //     {
                //         "empID":206,
                //         "empName":"Suresh Sayammagaru 2",
                //         "empDesg":"VP",
                //         "repMangId":0,
                //         "repMangName":""
                //     },
                //     {
                //         "empID":123,
                //         "empName":"Wahengbam Paramjit Singh",
                //         "empDesg":"M",
                //         "repMangId":206,
                //         "repMangName":"Suresh Sayammagaru"
                //     },
                //     {
                //         "empID":156,
                //         "empName":"Adhithya Karthikeyan",
                //         "empDesg":"BA",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     },
                //     {
                //         "empID":173,
                //         "empName":"Selvaraj Sebastian Srikanth Kumar",
                //         "empDesg":"BA",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     },
                //     {
                //         "empID":333,
                //         "empName":"Sravan Kumar Raju",
                //         "empDesg":"C",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     }
                //     ]
                // },
                // {
                //     "scenario":"Scenario 3",
                //     "created_by": 206,
                //     "create_time":"02 / 06 / 2021 15: 56: 29",
                //     "org_structure":[
                //     {
                //         "empID":206,
                //         "empName":"Suresh Sayammagaru 3",
                //         "empDesg":"VP",
                //         "repMangId":0,
                //         "repMangName":""
                //     },
                //     {
                //         "empID":123,
                //         "empName":"Wahengbam Paramjit Singh",
                //         "empDesg":"M",
                //         "repMangId":206,
                //         "repMangName":"Suresh Sayammagaru"
                //     },
                //     {
                //         "empID":156,
                //         "empName":"Adhithya Karthikeyan",
                //         "empDesg":"BA",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     },
                //     {
                //         "empID":173,
                //         "empName":"Selvaraj Sebastian Srikanth Kumar",
                //         "empDesg":"BA",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     },
                //     {
                //         "empID":333,
                //         "empName":"Sravan Kumar Raju",
                //         "empDesg":"C",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     }
                //     ]
                // },
                // {
                //     "scenario":"Scenario 4",
                //     "created_by": 206,
                //     "create_time":"02 / 06 / 2021 15: 56: 29",
                //     "org_structure":[
                //     {
                //         "empID":206,
                //         "empName":"Suresh Sayammagaru 4",
                //         "empDesg":"VP",
                //         "repMangId":0,
                //         "repMangName":""
                //     },
                //     {
                //         "empID":123,
                //         "empName":"Wahengbam Paramjit Singh",
                //         "empDesg":"M",
                //         "repMangId":206,
                //         "repMangName":"Suresh Sayammagaru"
                //     },
                //     {
                //         "empID":156,
                //         "empName":"Adhithya Karthikeyan",
                //         "empDesg":"BA",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     },
                //     {
                //         "empID":173,
                //         "empName":"Selvaraj Sebastian Srikanth Kumar",
                //         "empDesg":"BA",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     },
                //     {
                //         "empID":333,
                //         "empName":"Sravan Kumar Raju",
                //         "empDesg":"C",
                //         "repMangId":123,
                //         "repMangName":"Wahengbam Paramjit Singh"
                //     }
                //     ]
                }
            ];
            
            // jsonData.forEach(scr => {
            //     var id = scr.scenario.replace(" ","_");
            //     console.log("id - "+id);
            //     $("#mySidenav").append("<a id="+id+" onClick='loadChart(\""+scr.scenario.trim()+"\")'>"+scr.scenario+"</a>");
            // });
            $('#org_chart_select').empty();
            //console.log('message: ' + "success"+ JSON.stringify(json)); 
            //jsonData = json
            console.log("jsonData scenario - ",jsonData);
            //console.log("Json SIze - ",Object.keys(jsonData.data).length)
            //jsonData.forEach(scr => {
                // var id = jsonData.scenario.replace(" ","_");
                // console.log("id new - "+id);
                // $("#mySidenav").append("<a id="+id+" onClick='loadChart(\""+jsonData.scenario.trim()+"\")'><img id='"+id+"_img' src='images\\organization-chart_icon.png' alt='Org Chart Icon' width='20' height='25' ><img id='"+id+"_img' src='images\\organization-chart_hover.png' alt='Org Chart Icon' width='20' height='25' > "+jsonData.data.DEFAULT.SCENARIO_NAME+"</a>");
                // $('#org_chart_select').append("<option id="+id+" onchange='loadChart(\""+jsonData.scenario.trim()+"\")' value="+jsonData.scenario+" >"+jsonData.scenario+"</option>");
                
                if(Object.keys(jsonData).length > 0){
                    scenario_list = jsonData;
                    scenario_list.forEach(scr => {
                        // console.log("scr - ",scr);
                        // console.log("scr.SCENARIO_NAME - ",scr.SCENARIO_NAME);
                        var id = scr.scenario.replace(" ","_");
                        $("#mySidenav").append("<a id="+id+" onClick='loadChart(\""+scr.scenario.trim()+"\")'><img id='"+id+"_img' src='images\\scenario_icon.png' alt='Org Chart Icon' width='20' height='25'><img id='"+id+"_img' src='images\\scenario_icon_hover.png' alt='Org Chart Icon' width='20' height='25'> "+scr.scenario+"</a>");
                        $('#org_chart_select').append("<option id="+id+" onchange='loadChart(\""+scr.scenario.trim()+"\")' value="+scr.scenario.trim()+">"+scr.scenario.trim()+"</option>");
                    });
                    
                }
            //});
            loadSOWChart("SOW Chart");
            $("#SOW_Chart").addClass("active");
            $('#SOW_Chart_img').attr('src', 'images\\organization-chart_hover.png');
            // console.log("Size - "+$(".jOrgChart").size());

            var org = [];
            org = jsonData.data;    
        }
    });
    
}

$(function () {
    $("#org_chart_select").change(function () {
        var selectedText = $(this).find("option:selected").text();
        var selectedValue = $(this).val();
        //alert("Selected Text: " + selectedText + " Value: " + selectedValue);
        loadChart(selectedText);
    });
});

/* Assigning JSON data into a list and append to ID */

function loadChart(scenario){
    revertChanges = [];
    if (revertChanges.length == 0) {
        $('#save').prop('disabled', true);
    }
    $( ".jOrgChart" ).remove();
    $('body').find('.active').removeClass();
    $('#Org_Chart_img').attr('src', 'images\\organization-chart_icon.png');
    var id = scenario.replace(" ","_");
    var id_img = id+"_img";
    //console.log("Size after - "+$(".jOrgChart").size());
    //console.log("scenario loop - ",scenario);
    //const empList = jsonData.find(scr => scr.scenario === scenario);
    //console.log("empList 1 -",empList);
    
    importedEmpList = [];
    existingEmpList = [];
    var id_count = $('#mySidenav a').length;
    // console.log("id Count New- "+id_count);
    for(let i=1; i < id_count; i++){
        console.log("Scenario_"+i);
        
        $("#Scenario_"+i+"_img").attr('src', 'images\\scenario_icon.png');
    }
    if(scenario == 'Org Chart'){
        
        const empList = jsonData.data.DEFAULT.ORG_STRUCTURE;
        $('#save').hide();
        $('#orgChart_final').hide();
        $('#Org_Chart_img').attr('src', 'images\\organization-chart_hover.png');
        if(empList){
            //console.log("empList - ",empList);
            /* Reading API json data with single scenarios */
            for (var i in empList){
                //console.log("empName - ",empList[i].EMPLOYEE_NAME);
                importedEmpList.push({
                    empName: empList[i].EMPLOYEE_NAME,
                    empId: Number(empList[i].EMPLOYEE_ID),
                    empDesg: empList[i].DESIGNATION,
                    repMangId: Number(empList[i].REPORTING_MANAGER_ID),
                    repMangName: empList[i].REPORTING_MANAGER,
                    dept: empList[i].DEPARTMENT,
                });
                existingEmpList.push({
                    empName: empList[i].EMPLOYEE_NAME,
                    empId: Number(empList[i].EMPLOYEE_ID),
                    empDesg: empList[i].DESIGNATION,
                    repMangId: Number(empList[i].REPORTING_MANAGER_ID),
                    repMangName: empList[i].REPORTING_MANAGER,
                    dept: empList[i].DEPARTMENT,
                });
            }
    
            //revertChanges.push(existingEmpList);
            //console.log("importedEmpList - ", importedEmpList);
            //console.log("existingEmpList - ", existingEmpList);
            //console.log("revertChanges  1 - ", revertChanges);
            //const mainParentEmpId = importedEmpList.find(emp => emp.repMangId == 0);
            $("#orgData").html(getReportingEmpData(0, true));
            $("#org").jOrgChart({
                chartElement: "#chart",
                dragAndDrop: true,
            });
            
        }
    }else{
        $('#save').show();
        $('#orgChart_final').show();
        $('#'+id_img).attr('src', 'images\\scenario_icon_hover.png');
        let scenarioData = jsonData.data.SAVED.find(scr => scr.SCENARIO_NAME === scenario);
        //console.log("scenarioData - ",scenarioData);
        //console.log("jsonData.data.SAVED.SCENARIO_NAME - ",jsonData.data.SAVED.SCENARIO_NAME);
        /* Displaying scenario data */
        if(scenarioData){
            let scenario = scenarioData.ORG_STRUCTURE
            // console.log("scenarioData loop - ",scenario);
            /* Reading API json data with single scenarios */
    
            for (var i in scenario){
                // console.log("empName Org - ",scenario[i].EMP_NAME);
                importedEmpList.push({
                    empName: scenario[i].EMPLOYEE_NAME,
                    empId: Number(scenario[i].EMPLOYEE_ID),
                    empDesg: scenario[i].DESIGNATION,
                    repMangId: Number(scenario[i].MANAGER_ID),
                    repMangName: scenario[i].MANAGER_NAME,
                    dept: scenario[i].DEPARTMENT,
                });
                existingEmpList.push({
                    empName: scenario[i].EMPLOYEE_NAME,
                    empId: Number(scenario[i].EMPLOYEE_ID),
                    empDesg: scenario[i].DESIGNATION,
                    repMangId: Number(scenario[i].MANAGER_ID),
                    repMangName: scenario[i].MANAGER_NAME,
                    dept: scenario[i].DEPARTMENT,
                });
            }
    
            //revertChanges.push(existingEmpList);
            // console.log("importedEmpList - ", importedEmpList);
            // console.log("existingEmpList - ", existingEmpList);
            // console.log("revertChanges 2 - ", revertChanges);
            //const mainParentEmpId = importedEmpList.find(emp => emp.repMangId == 0);
            $("#orgData").html(getReportingEmpData(0, true));
            $("#org").jOrgChart({
                chartElement: "#chart",
                dragAndDrop: true,
            });
        }
    }

    $("#"+id).addClass("active");
    $(".jOrgChart").addClass("table-responsive");
    $(".jOrgChart").css("width", "100%");
}

function loadSOWChart(scenario){
    revertChanges = [];
    if (revertChanges.length == 0) {
        $('#save').prop('disabled', true);
    }
    $( ".jOrgChart" ).remove();
    $('body').find('.active').removeClass();
    $('#SOW_Chart_img').attr('src', 'images\\organization-chart_icon.png');
    var id = scenario.replace(" ","_");
    var id_img = id+"_img";
    //console.log("Size after - "+$(".jOrgChart").size());
    //console.log("scenario loop - ",scenario);
    //const empList = jsonData.find(scr => scr.scenario === scenario);
    //console.log("empList 1 -",empList);
    
    importedEmpList = [];
    existingEmpList = [];
    var id_count = $('#mySidenav a').length;
    // console.log("id Count New- "+id_count);
    for(let i=1; i < id_count; i++){
        console.log("Scenario_"+i);
        
        $("#Scenario_"+i+"_img").attr('src', 'images\\scenario_icon.png');
    }
    if(scenario == 'SOW Chart'){
        
        const empList = jsonData[0].org_structure;
        $('#save').hide();
        $('#orgChart_final').hide();
        $('#Org_Chart_img').attr('src', 'images\\organization-chart_hover.png');
        if(empList){
            //console.log("empList - ",empList);
            /* Reading API json data with single scenarios */
            for (var i in empList){
                //console.log("empName - ",empList[i].EMPLOYEE_NAME);
                importedEmpList.push({
                    empName: empList[i].empName,
                    empId: Number(empList[i].empID),
                    empDesg: empList[i].empDesg,
                    repMangId: Number(empList[i].repMangId),
                    repMangName: empList[i].repMangName,
                    dept: "",
                });
                existingEmpList.push({
                    empName: empList[i].empName,
                    empId: Number(empList[i].empID),
                    empDesg: empList[i].empDesg,
                    repMangId: Number(empList[i].repMangId),
                    repMangName: empList[i].repMangName,
                    dept: "",
                });
            }
    
            //revertChanges.push(existingEmpList);
            //console.log("importedEmpList - ", importedEmpList);
            //console.log("existingEmpList - ", existingEmpList);
            //console.log("revertChanges  1 - ", revertChanges);
            //const mainParentEmpId = importedEmpList.find(emp => emp.repMangId == 0);
            $("#orgData").html(getReportingSOWData(0, true));
            $("#org").jOrgChart({
                chartElement: "#chart",
                dragAndDrop: true,
            });
            
        }
    }else{
        $('#save').show();
        $('#orgChart_final').show();
        $('#'+id_img).attr('src', 'images\\scenario_icon_hover.png');
        let scenarioData = jsonData.data.SAVED.find(scr => scr.SCENARIO_NAME === scenario);
        //console.log("scenarioData - ",scenarioData);
        //console.log("jsonData.data.SAVED.SCENARIO_NAME - ",jsonData.data.SAVED.SCENARIO_NAME);
        /* Displaying scenario data */
        if(scenarioData){
            let scenario = scenarioData.ORG_STRUCTURE
            // console.log("scenarioData loop - ",scenario);
            /* Reading API json data with single scenarios */
    
            for (var i in scenario){
                // console.log("empName Org - ",scenario[i].EMP_NAME);
                importedEmpList.push({
                    empName: scenario[i].empName,
                    empId: Number(scenario[i].empID),
                    empDesg: scenario[i].empDesg,
                    repMangId: Number(scenario[i].repMangId),
                    repMangName: scenario[i].repMangName,
                    dept: "",
                });
                existingEmpList.push({
                    empName: scenario[i].empName,
                    empId: Number(scenario[i].empID),
                    empDesg: scenario[i].empDesg,
                    repMangId: Number(scenario[i].repMangId),
                    repMangName: scenario[i].repMangName,
                    dept: "",
                });
            }
    
            //revertChanges.push(existingEmpList);
            // console.log("importedEmpList - ", importedEmpList);
            // console.log("existingEmpList - ", existingEmpList);
            // console.log("revertChanges 2 - ", revertChanges);
            //const mainParentEmpId = importedEmpList.find(emp => emp.repMangId == 0);
            $("#orgData").html(getReportingSOWData(0, true));
            $("#org").jOrgChart({
                chartElement: "#chart",
                dragAndDrop: true,
            });
        }
    }

    $("#"+id).addClass("active");
    $(".jOrgChart").addClass("table-responsive");
    $(".jOrgChart").css("width", "100%");
}

let revertCount = 0;

function revertCountFun() {
    if (revertChanges.length > 0 && revertCount > 0) {
        revertCount = revertCount - 1;
    }
    return revertCount;
}

function getReportingEmpData(repMangId, isFirstRecord) {
    const mainParentEmpId = importedEmpList.find(emp => emp.repMangId == 0);
    const reportes = importedEmpList.filter(
        (emp) => emp.repMangId == repMangId
    );
    // revertCountFun()
    // const mainParentEmpId = revertChanges[revertCount].find(emp => emp.repMangId == 0);
    // const reportes = revertChanges[revertCount].filter(
    //     (emp) => emp.repMangId == repMangId
    // );
    let reportesData = "<ul " + (isFirstRecord ? "id='org'" : "") + ">";
    //if(isFirstRecord){
    // reportesData = reportesData + "<li> <span>"+employee.empName+"</span> <br><br><br><span>"+employee.empDesg+" (0)</span>";
    //}
    let rEmpData = "";
    reportes.forEach((emp) => {
        //rEmpData = rEmpData + "<li> <span class='emp-name'>"+emp.empName+"</span> <br><br><br><span class='emp-desg'>"+emp.empDesg+" ("+importedEmpList.filter(iemp => iemp.repMangId == emp.empId).length+")</span>";
        let empCardClassName = '';
        if (emp.empDesg === 'CEO') {
            empCardClassName = 'class-ceo';
        }else if (emp.empDesg === 'Vice President') {
            empCardClassName = 'class-vp';
        } else if (emp.empDesg === 'Associate Director') {
            empCardClassName = 'class-ad';
        } else if (emp.empDesg === 'Senior Manager') {
            empCardClassName = 'class-sm';
        } else if (emp.empDesg === 'Manager') {
            empCardClassName = 'class-m';
        }else if (emp.empName === 'Factspan') {
            empCardClassName = 'class-factspan';
        }else if (emp.empName === 'ACI') {
            empCardClassName = 'class-aci';
        }else if (emp.empName === 'Albertsons') {
            empCardClassName = 'class-albertsons';
        }else if (emp.empName === 'Anthem') {
            empCardClassName = 'class-anthem';
        }else if (emp.empName === 'Disney') {
            empCardClassName = 'class-disney';
        }else if (emp.empName === 'HCA') {
            empCardClassName = 'class-hca';
        }else if (emp.empName === 'LeadVenture') {
            empCardClassName = 'class-leadventure';
        }else if (emp.empName === 'LifeLock') {
            empCardClassName = 'class-lifelock';
        }else if (emp.empName === 'Macys') {
            empCardClassName = 'class-macys';
        } else {
            empCardClassName = 'class-default';
        }
        rEmpData =
            rEmpData +
            "<li class= '" + empCardClassName + " " + ((emp.collapsed !== undefined) ?
                (emp.collapsed ? 'collapsed' : '') :
                (!(repMangId == 0) ? 'collapsed' : '')) +
            "' > <span class='emp-name " + empCardClassName + "-name'>" +
            emp.empName +
            "</span> <br><br><span class='emp-desg " + empCardClassName + "-desg'>" +
            emp.empDesg +
            "</span><br> <span class='" + empCardClassName + "-count'>DR - (" +
            importedEmpList.filter((iemp) => iemp.repMangId == emp.empId)
            .length +
            ")</span> <span class='" + empCardClassName + "-count' >TR - (" +
            getChildListLength(emp.empId) + ") </span>" +
            "<input type='hidden' class='emp-id' value='" +
            emp.empId +
            "'><input type='hidden' class='emp-repMangId' value='" +
            emp.repMangId +
            "'><input type='hidden' class='emp-repMangName' value='" +
            emp.repMangName +
            "'> <input type='hidden' class='emp-dept' value='" + emp.dept + "'> ";

        rEmpData = rEmpData + getReportingEmpData(emp.empId, false);

        rEmpData = rEmpData + "</li>";
    });
    if (rEmpData != "") {
        reportesData = reportesData + rEmpData;
    }

    reportesData = reportesData + "</ul>";


    return reportesData;
}

function getReportingSOWData(repMangId, isFirstRecord) {
    const mainParentEmpId = importedEmpList.find(emp => emp.repMangId == 0);
    const reportes = importedEmpList.filter(
        (emp) => emp.repMangId == repMangId
    );
    // revertCountFun()
    // const mainParentEmpId = revertChanges[revertCount].find(emp => emp.repMangId == 0);
    // const reportes = revertChanges[revertCount].filter(
    //     (emp) => emp.repMangId == repMangId
    // );
    let reportesData = "<ul " + (isFirstRecord ? "id='org'" : "") + ">";
    //if(isFirstRecord){
    // reportesData = reportesData + "<li> <span>"+employee.empName+"</span> <br><br><br><span>"+employee.empDesg+" (0)</span>";
    //}
    let rEmpData = "";
    reportes.forEach((emp) => {
        //rEmpData = rEmpData + "<li> <span class='emp-name'>"+emp.empName+"</span> <br><br><br><span class='emp-desg'>"+emp.empDesg+" ("+importedEmpList.filter(iemp => iemp.repMangId == emp.empId).length+")</span>";
        let empCardClassName = '';
        if (emp.empDesg === 'VP') {
            empCardClassName = 'class-vp';
        } else if (emp.empDesg === 'AD') {
            empCardClassName = 'class-ad';
        } else if (emp.empDesg === 'SM') {
            empCardClassName = 'class-sm';
        } else if (emp.empDesg === 'M') {
            empCardClassName = 'class-m';
        }else if (emp.empName === 'Factspan') {
            empCardClassName = 'class-factspan';
        }else if (emp.empName === 'ACI') {
            empCardClassName = 'class-aci';
        }else if (emp.empName === 'Albertsons') {
            empCardClassName = 'class-albertsons';
        }else if (emp.empName === 'Anthem') {
            empCardClassName = 'class-anthem';
        }else if (emp.empName === 'Disney') {
            empCardClassName = 'class-disney';
        }else if (emp.empName === 'HCA') {
            empCardClassName = 'class-hca';
        }else if (emp.empName === 'LeadVenture') {
            empCardClassName = 'class-leadventure';
        }else if (emp.empName === 'LifeLock') {
            empCardClassName = 'class-lifelock';
        }else if (emp.empName === 'Macys') {
            empCardClassName = 'class-macys';
        } else {
            empCardClassName = 'class-default';
        }
        rEmpData =
            rEmpData +
            "<li class= '" + empCardClassName + " " + ((emp.collapsed !== undefined) ?
                (emp.collapsed ? 'collapsed' : '') :
                (!(repMangId == 0) ? 'collapsed' : '')) +
            "' > <span class='emp-name " + empCardClassName + "-name'>" +
            emp.empName +
            "</span> <br><br><span class='emp-desg " + empCardClassName + "-desg'>" +
            emp.empDesg +
            "</span><br> <span class='" + empCardClassName + "-count' >TR - (" +
            getChildListLength(emp.empId) + ") </span>" +
            "<input type='hidden' class='emp-id' value='" +
            emp.empId +
            "'><input type='hidden' class='emp-repMangId' value='" +
            emp.repMangId +
            "'><input type='hidden' class='emp-repMangName' value='" +
            emp.repMangName +
            "'>";

        rEmpData = rEmpData + getReportingSOWData(emp.empId, false);

        rEmpData = rEmpData + "</li>";
    });
    if (rEmpData != "") {
        reportesData = reportesData + rEmpData;
    }

    reportesData = reportesData + "</ul>";


    return reportesData;
}

function getChildListLength(repMangId) {
    const reportes = importedEmpList.filter(
        (emp) => emp.repMangId == repMangId
    );
    let len = reportes.length;
    reportes.forEach((emp) => {
        len = len + getChildListLength(emp.empId);
    });
    return len;
}

function FetchChild() {
    var data = [];
    $("#org > li").each(function() {
        data.push(buildJSON($(this)));
    });

    return data;
}

let serialNumber = 1;


function buildJSON($li) {
    var subObj = {
        name: $li.contents().eq(0).text().trim() ||
            $li.find('[class="emp-name"]').text().trim(),
        // "icon": $li.find('i').attr('class'),
        // "to": $li.find('a').attr('href')
    };
    importedEmpList.push({
        //sNo: serialNumber,
        empName: $li.find(">.emp-name").text(),
        empId: Number($li.find(".emp-id").val()),
        empDesg: $li.find(">.emp-desg").text(),
        repMangId: Number($li.find(".emp-repMangId").val()),
        repMangName: $li.find(".emp-repMangName").val(),
        dept: $li.find(".emp-dept").val(),
        collapsed: $li.hasClass('collapsed'),
       // dateTime: getDateTime()

    });
    serialNumber = serialNumber + 1;
    //console.log("importedEmpList Json - ",importedEmpList);
    $li
        .children("ul")
        .children()
        .each(function() {
            if (!subObj.children) {
                subObj.children = [];
            }
            subObj.children.push(buildJSON($(this)));
        });
    return subObj;
}

function resetAndUpdate() {
    console.log("reset");
    importedEmpList = [];
    var obj = FetchChild();
    revertChanges.push(importedEmpList);
    console.log("importedEmpList Reset - ", importedEmpList);
    console.log("revertChanges 3 - ", revertChanges);
    console.log("revert Changes length - " + revertChanges.length);
    $("#orgData").html(getReportingEmpData(0, true));
    $("#org").jOrgChart({
        chartElement: "#chart",
        dragAndDrop: true,
    });
    if (revertChanges.length > 0) {
        $('#save').prop('disabled', false);
    }
}

//Converting Json to CSV file

function convertToCSV(objArray) {
    var array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    var str = '';

    for (var i = 0; i < array.length; i++) {
        var line = '';
        for (var index in array[i]) {
            if (line != '') line += ','

            line += array[i][index];
        }

        str += line + '\r\n';
    }

    return str;
}

function exportCSVFile(headers, items, fileTitle) {
    if (headers) {
        items.unshift(headers);
    }

    // Convert Object to JSON
    var jsonObject = JSON.stringify(items);

    var csv = this.convertToCSV(jsonObject);

    var exportedFilenmae = fileTitle + '.csv' || 'export.csv';

    var blob = new Blob([csv], {
        type: 'text/csv;charset=utf-8;'
    });
    if (navigator.msSaveBlob) { // IE 10+
        navigator.msSaveBlob(blob, exportedFilenmae);
    } else {
        var link = document.createElement("a");
        if (link.download !== undefined) { // feature detection
            // Browsers that support HTML5 download attribute
            var url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", exportedFilenmae);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    }
}

function download() {
    var headers = {
        sNo: 'S No',
        empName: 'Name of the Employee'.replace(/,/g, ''), // remove commas to avoid errors
        empId: "Emp ID",
        empDesg: "Designation".replace(/,/g, ''),
        repMangId: "Project Manager ID".replace(/,/g, ''),
        repMangName: "Reporting Manager".replace(/,/g, ''),
        //dept: "Department".replace(/,/g, ''),
        //dateTime: "Date and Time".replace(/,/g, '')
    };

    itemsNotFormatted = importedEmpList;

    var itemsFormatted = [];

    // format the data
    // itemsNotFormatted.forEach((item) => {
    //     itemsFormatted.push({
    //         sNo: item.sNo,
    //         empName: item.empName.replace(/,/g, ''), // remove commas to avoid errors,
    //         empId: item.empId,
    //         empDesg: item.empDesg.replace(/,/g, ''),
    //         repMangId: item.repMangId,
    //         repMangName: item.repMangName.replace('\r', '').replace('\n', ''),
    //         //dept: item.dept,
    //         //dateTime: item.dateTime.replace(/,/g, ''),
    //     });
    // });
    itemsNotFormatted.forEach((item) => {
        itemsFormatted.push({
            sNo: item.sNo,
            empName: item.empName.replace(/,/g, ''), // remove commas to avoid errors,
            empId: item.empId,
            empDesg: item.empDesg.replace(/,/g, ''),
            repMangId: item.repMangId,
            repMangName: item.repMangName,
            //dept: item.dept,
            //dateTime: item.dateTime.replace(/,/g, ''),
        });
    });
    console.log("itemsFormatted - ",itemsFormatted);

    var fileTitle = 'Org_Structure_gen'; // or 'my-unique-title'

    exportCSVFile(headers, itemsFormatted, fileTitle); // call the exportCSVFile() function to process the JSON and trigger the download
}

function revertChangesFun() {
    revertChanges.length = revertChanges.length - 1;
    importedEmpList = revertChanges[revertChanges.length - 1];
    if (revertChanges.length <= 1) {
        $('#revert').prop('disabled', true);
    } else {
        $('#revert').prop('disabled', false);
    }
    $('#chart').children().remove();
    $('#orgData').html(getReportingEmpData(0, true));
    $('#org').jOrgChart({
        chartElement: "#chart",
        dragAndDrop: true,
    });
}

function createScenario(){
    //download();
    var id_count = $('#mySidenav a').length;
    console.log("id Count - "+id_count);
    // $("#mySidenav").append("<a id=Scenario_"+id_count+" onClick='loadChart(\"Scenario "+id_count+"\")'>Scenario "+id_count+"</a>");
    var createData = "";
    let jsonCreation = "";
    importedEmpList.forEach((emp) => {
        jsonCreation = jsonCreation + "{ \"EMPLOYEE_ID\" : " +emp.empId + 
                            ", \"EMPLOYEE_NAME\":\""+emp.empName+
                            "\", \"DESIGNATION\":\""+emp.empDesg+
                            "\", \"DEPARTMENT\":\""+emp.dept+
                            "\", \"MANAGER_ID\":"+emp.repMangId+
                            ", \"MANAGER_NAME\":\""+emp.repMangName+
                            "\", \"REPORTING_MANAGER\":\"\"},"

    });
    //console.log("jsonCreation - ",jsonCreation);
    if (jsonCreation.endsWith(",")){
        jsonCreation = jsonCreation.slice(0, -1);
        //console.log("jsonCreation slice - ",jsonCreation);
     }
     let new_date = getDateTime();
     let scn_name_filter = scenario_list.filter(s => s.SCENARIO_NAME.includes(new_date));
     let dateFilterList = scenario_list.filter(s => s.SCENARIO_NAME.includes(new_date));
     let newScenarioName = dateFilterList.length > 0 ? "SCN_"+new_date+"_" + (dateFilterList.length + 1) : "SCN_"+new_date+"_1" ;
    //  console.log("newScenarioName - "+newScenarioName)
    createData = {
        //"SCENARIO_NAME":"Scenario "+id_count,
        "SCENARIO_NAME":newScenarioName,
        //"CREATED_BY": 206,
        "CREATED_BY": 1486,
        "MODE":"insert",
        "ORG_STRUCTURE":"["+jsonCreation+"]"
    }
    // console.log("createData - ",createData);
    $.ajax({
        // url: "http://127.0.0.1:5000/insertscenario",
        // url: "http://192.168.30.155:5000/insertscenario",
        url: "https://rre-api.factspanapps.com:5000/insertscenario",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        data: createData,
        success:function(json){
            console.log("success");
            getData();
            $("#mySidenav").find("a:last-child").click();
            toastr.options.timeOut = 2000; // 2s
            toastr.success('Scenario created successfully');
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
            toastr.options.timeOut = 2000; // 2s
            toastr.success('Message error' + JSON.stringify(error));
        }  
    }); 
}

function saveScenario() {
    let selectedValue = $(".active").text().trim();
    console.log("selectedValue - ",selectedValue.trim());
    let updateData = "";
    let jsonCreation = "";
    let updatedList = [];
    let changeVal = revertChanges.length - 1;
    // console.log("revertChanges.length 1 - ",changeVal);
    updatedList = revertChanges[changeVal];
    // console.log("updatedList - ",updatedList);
    updatedList.forEach((emp) => {
        jsonCreation = jsonCreation + "{ \"EMPLOYEE_ID\" : " +emp.empId + 
                            ", \"EMPLOYEE_NAME\":\""+emp.empName+
                            "\", \"DESIGNATION\":\""+emp.empDesg+
                            "\", \"DEPARTMENT\":\""+emp.dept+
                            "\", \"MANAGER_ID\":"+emp.repMangId+
                            ", \"MANAGER_NAME\":\""+emp.repMangName+
                            "\", \"REPORTING_MANAGER\":\"\"},"

    });
    //console.log("jsonCreation - ",jsonCreation);
    if (jsonCreation.endsWith(",")){
        jsonCreation = jsonCreation.slice(0, -1);
        //console.log("jsonCreation slice - ",jsonCreation);
     }
    updateData = {
        "SCENARIO_NAME":selectedValue,
        // "CREATED_BY": 206,
        "CREATED_BY": 1486,
        "MODE":"update",
        "ORG_STRUCTURE":"["+jsonCreation+"]"
    }
    console.log("createData list - ",updateData);
    console.log("revertChanges 4 - ", revertChanges);
    $.ajax({
        // url: "http://127.0.0.1:5000/updatescenario",
        // url: "http://192.168.30.155:5000/updatescenario",
        url: "https://rre-api.factspanapps.com:5000/updatescenario",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        data: updateData,
        success:function(json){
            console.log("success");
            let id = selectedValue.replaceAll(" ","_");
            console.log("id - ",id);
            getData();
            $("#mySidenav").find("#"+id).click();
            toastr.options.timeOut = 2000; // 2s
            toastr.success('Scenario updated successfully');
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
            toastr.options.timeOut = 2000; // 2s
            toastr.success('Message error' + JSON.stringify(error));
        }  
    }); 

}

function saveOrgChart() {
    let selectedValue = $(".active").html();
    console.log("selectedValue - ",selectedValue);
    let updateData = "";
    let jsonCreation = "";
    let updatedList = [];
    if(revertChanges.length != 0){
        let changeVal = revertChanges.length - 1;
        console.log("revertChanges.length 1 - ",changeVal);
        updatedList = revertChanges[changeVal];
    }else{
        updatedList = importedEmpList;
    }
    console.log("updatedList - ",updatedList);
    updatedList.forEach((emp) => {
        jsonCreation = jsonCreation + "{ \"EMPLOYEE_ID\" : " +emp.empId + 
                            ", \"EMPLOYEE_NAME\":\""+emp.empName+
                            "\", \"DESIGNATION\":\""+emp.empDesg+
                            "\", \"DEPARTMENT\":\""+emp.dept+
                            "\", \"MANAGER_ID\":"+emp.repMangId+
                            ", \"MANAGER_NAME\":\""+emp.repMangName+
                            "\", \"REPORTING_MANAGER\":\"\"},"

    });
    //console.log("jsonCreation - ",jsonCreation);
    if (jsonCreation.endsWith(",")){
        jsonCreation = jsonCreation.slice(0, -1);
        //console.log("jsonCreation slice - ",jsonCreation);
     }
    updateData = {
        "SCENARIO_NAME":selectedValue,
        //"CREATED_BY": 206,
        "CREATED_BY": 1486,
        "MODE":"insert",
        "ORG_STRUCTURE":"["+jsonCreation+"]"
    }
    console.log("createData list - ",updateData);
    console.log("revertChanges 4 - ", revertChanges);
    $.ajax({
        // url: "http://127.0.0.1:5000/finalscenario",
        // url: "http://192.168.30.155:5000/finalscenario",
        url: "https://rre-api.factspanapps.com:5000/finalscenario",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        data: updateData,
        success:function(json){
            console.log("success");
            let id = selectedValue.replaceAll(" ","_");
            console.log("id - ",id);
            getData();
            $("#mySidenav").find("#Org_Chart").click();
            toastr.options.timeOut = 2000; // 2s
            toastr.success('Org chart saved successfully');
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
            toastr.options.timeOut = 2000; // 2s
            toastr.success('Message error' + JSON.stringify(error));
        }  
    }); 

}

