
    // var sow_rsrc_allow_sum = [
    //     {
    //         "sow_id": "1001",
    //         "sow_code": "ACI-FRD-001",
    //         "account": "Disney",
    //         "sow_name": "BOH",
    //         "sow_status":"",
    //         "ind":5,
    //         "us":0.5,
    //         "ind_associate": 1,
    //         "ind_analyst":2,
    //         "ind_sr_analyst": 2,
    //         "ind_am": "",
    //         "ind_manager_sr_manager": 1,
    //         "ind_sme":"",
    //         "us_associate": 0.5,
    //         "us_analyst":"",
    //         "us_sr_analyst": "",
    //         "us_am": "",
    //         "us_manager_sr_manager": "",
    //         "us_sme":"",
    //         "tot_billed":"",
    //         "tot_buffer":"",
    //         "tot_invest":"",
    //         "ind_billed":"",
    //         "ind_buffer":"",
    //         "ind_invest":"",
    //         "us_billed":"",
    //         "us_buffer":"",
    //         "us_invest":""
    //     },
    //     {
    //         "sow_id": "1001",
    //         "sow_code": "ACI-FRD-001",
    //         "account": "Disney",
    //         "sow_name": "M&S",
    //         "sow_status":"",
    //         "ind":2.25,
    //         "us":"",
    //         "ind_associate": "",
    //         "ind_analyst":1,
    //         "ind_sr_analyst": 1,
    //         "ind_am": "",
    //         "ind_manager_sr_manager": "",
    //         "ind_sme":0.25,
    //         "us_associate": "",
    //         "us_analyst":"",
    //         "us_sr_analyst": "",
    //         "us_am": "",
    //         "us_manager_sr_manager": "",
    //         "us_sme":"",
    //         "tot_billed":"",
    //         "tot_buffer":"",
    //         "tot_invest":"",
    //         "ind_billed":"",
    //         "ind_buffer":"",
    //         "ind_invest":"",
    //         "us_billed":"",
    //         "us_buffer":"",
    //         "us_invest":""
    //     },
    //     {
    //         "sow_id": "1002",
    //         "sow_code": "ACI-NLP-002",
    //         "account": "Disney",
    //         "sow_name": "IA Ticketing",
    //         "sow_status":"",
    //         "ind":3,
    //         "us":0.25,
    //         "ind_associate": 1,
    //         "ind_analyst":1,
    //         "ind_sr_analyst": 1,
    //         "ind_am": "",
    //         "ind_manager_sr_manager": "",
    //         "ind_sme":"",
    //         "us_associate": 0.25,
    //         "us_analyst":"",
    //         "us_sr_analyst": "",
    //         "us_am": "",
    //         "us_manager_sr_manager": "",
    //         "us_sme":"",
    //         "tot_billed":"",
    //         "tot_buffer":"",
    //         "tot_invest":"",
    //         "ind_billed":"",
    //         "ind_buffer":"",
    //         "ind_invest":"",
    //         "us_billed":"",
    //         "us_buffer":"",
    //         "us_invest":""
    //     },
    //     {
    //         "sow_id": "1003",
    //         "sow_code": "ALB-FFM-001",
    //         "account": "Disney",
    //         "sow_name": "DCLRMS",
    //         "sow_status":"",
    //         "ind":10,
    //         "us":1,
    //         "ind_associate": 1,
    //         "ind_analyst":3,
    //         "ind_sr_analyst": 3,
    //         "ind_am": 2,
    //         "ind_manager_sr_manager": 1,
    //         "ind_sme":"",
    //         "us_associate": 1,
    //         "us_analyst":"",
    //         "us_sr_analyst": "",
    //         "us_am": "",
    //         "us_manager_sr_manager": "",
    //         "us_sme":"",
    //         "tot_billed":"",
    //         "tot_buffer":"",
    //         "tot_invest":"",
    //         "ind_billed":"",
    //         "ind_buffer":"",
    //         "ind_invest":"",
    //         "us_billed":"",
    //         "us_buffer":"",
    //         "us_invest":""
    //     },
    //     {
    //         "sow_id": "1003",
    //         "sow_code": "ALB-FFM-001",
    //         "account": "Disney",
    //         "sow_name": "DLP",
    //         "sow_status":"",
    //         "ind":5,
    //         "us":0.5,
    //         "ind_associate": 1,
    //         "ind_analyst":1,
    //         "ind_sr_analyst": 2,
    //         "ind_am": "",
    //         "ind_manager_sr_manager": 1,
    //         "ind_sme":"",
    //         "us_associate": 0.5,
    //         "us_analyst":"",
    //         "us_sr_analyst": "",
    //         "us_am": "",
    //         "us_manager_sr_manager": "",
    //         "us_sme":"",
    //         "tot_billed":"",
    //         "tot_buffer":"",
    //         "tot_invest":"",
    //         "ind_billed":"",
    //         "ind_buffer":"",
    //         "ind_invest":"",
    //         "us_billed":"",
    //         "us_buffer":"",
    //         "us_invest":""
    //     },
    //     {
    //         "sow_id": "1003",
    //         "sow_code": "ALB-FFM-001",
    //         "account": "Disney",
    //         "sow_name": "Sustainment",
    //         "sow_status":"",
    //         "ind":6,
    //         "us":0.5,
    //         "ind_associate": 1,
    //         "ind_analyst":2,
    //         "ind_sr_analyst": 2,
    //         "ind_am": "",
    //         "ind_manager_sr_manager": 1,
    //         "ind_sme":"",
    //         "us_associate": 0.5,
    //         "us_analyst":"",
    //         "us_sr_analyst": "",
    //         "us_am": "",
    //         "us_manager_sr_manager": "",
    //         "us_sme":"",
    //         "tot_billed":"",
    //         "tot_buffer":"",
    //         "tot_invest":"",
    //         "ind_billed":"",
    //         "ind_buffer":"",
    //         "ind_invest":"",
    //         "us_billed":"",
    //         "us_buffer":"",
    //         "us_invest":""
    //     },
    //     {
    //         "sow_id": "1004",
    //         "sow_code": "ALB-LYL-002",
    //         "account": "HCA",
    //         "sow_name": "DE & Reporting",
    //         "sow_status":"",
    //         "ind":3,
    //         "us":0.25,
    //         "ind_associate": 1,
    //         "ind_analyst":1,
    //         "ind_sr_analyst": 1,
    //         "ind_am": "",
    //         "ind_manager_sr_manager": "",
    //         "ind_sme":"",
    //         "us_associate": 0.25,
    //         "us_analyst":"",
    //         "us_sr_analyst": "",
    //         "us_am": "",
    //         "us_manager_sr_manager": "",
    //         "us_sme":"",
    //         "tot_billed":"",
    //         "tot_buffer":"",
    //         "tot_invest":"",
    //         "ind_billed":"",
    //         "ind_buffer":"",
    //         "ind_invest":"",
    //         "us_billed":"",
    //         "us_buffer":"",
    //         "us_invest":""
    //     },
    //     {
    //         "sow_id": "1005",
    //         "sow_code": "ALB-MKT-003",
    //         "account": "LeadVenture",
    //         "sow_name": "Data Lake",
    //         "sow_status":"",
    //         "ind":1.25,
    //         "us":"",
    //         "ind_associate": "",
    //         "ind_analyst":1,
    //         "ind_sr_analyst": "",
    //         "ind_am": "",
    //         "ind_manager_sr_manager": "",
    //         "ind_sme":0.25,
    //         "us_associate": "",
    //         "us_analyst":"",
    //         "us_sr_analyst": "",
    //         "us_am": "",
    //         "us_manager_sr_manager": "",
    //         "us_sme":"",
    //         "tot_billed":"",
    //         "tot_buffer":"",
    //         "tot_invest":"",
    //         "ind_billed":"",
    //         "ind_buffer":"",
    //         "ind_invest":"",
    //         "us_billed":"",
    //         "us_buffer":"",
    //         "us_invest":""
    //     },
    //     {
    //         "sow_id": "1006",
    //         "sow_code": "ALB-MER-004",
    //         "account": "LifeLock",
    //         "sow_name": "Marketing Analytics",
    //         "sow_status":"",
    //         "ind":3,
    //         "us":0.25,
    //         "ind_associate": 1,
    //         "ind_analyst":1,
    //         "ind_sr_analyst": 1,
    //         "ind_am": "",
    //         "ind_manager_sr_manager": "",
    //         "ind_sme":"",
    //         "us_associate": 0.25,
    //         "us_analyst":"",
    //         "us_sr_analyst": "",
    //         "us_am": "",
    //         "us_manager_sr_manager": "",
    //         "us_sme":"",
    //         "tot_billed":"",
    //         "tot_buffer":"",
    //         "tot_invest":"",
    //         "ind_billed":"",
    //         "ind_buffer":"",
    //         "ind_invest":"",
    //         "us_billed":"",
    //         "us_buffer":"",
    //         "us_invest":""
    //     },
    //     {
    //         "sow_id": "1006",
    //         "sow_code": "ALB-MER-004",
    //         "account": "Macys",
    //         "sow_name": "Data Governance - (Yannique)",
    //         "sow_status":"",
    //         "ind":11,
    //         "us":1,
    //         "ind_associate": 2,
    //         "ind_analyst":3,
    //         "ind_sr_analyst": 3,
    //         "ind_am": 2,
    //         "ind_manager_sr_manager": 1,
    //         "ind_sme":"",
    //         "us_associate": 1,
    //         "us_analyst":"",
    //         "us_sr_analyst": "",
    //         "us_am": "",
    //         "us_manager_sr_manager": "",
    //         "us_sme":"",
    //         "tot_billed":"",
    //         "tot_buffer":"",
    //         "tot_invest":"",
    //         "ind_billed":"",
    //         "ind_buffer":"",
    //         "ind_invest":"",
    //         "us_billed":"",
    //         "us_buffer":"",
    //         "us_invest":""
    //     }
    // ]
function getRecomData() {
    var empData = [];
    let status = "";
    let endDate = "";
    $.ajax({
        url: "https://rre-api.factspanapps.com:5000/app",
        // url : "http://localhost:5770/app",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        async: false,
        mode: 'no-cors',
        data : {
            query_type : "select",
            db_name : "rre_db",
            table_name : "SOW_RESOURCE_ALLOCATION_SUMMARY",
            columns : "",
            filter : ""
        },
        success:function(data){
            jsonData = data
            data = jsonData.data.Details;
            console.log("SOW_RESOURCE_ALLOCATION_SUMMARY - ",data);
            for (var i=0; i<data.length; i++) {
                var row = $('<tr><td>' + data[i].SOW_ID+ '</td><td>' + 
                data[i].SOW_CODE + '</td><td>' + 
                data[i].CUSTOMER_NAME + '</td><td>' + 
                data[i].SOW_NAME + '</td><td>' + 
                data[i].STATUS + '</td><td>' + 
                data[i].INDIA + '</td><td>' + 
                data[i].USA + '</td><td>' + 
                data[i].Associate_ + '</td><td>' + 
                data[i].Analyst_ + '</td><td>' + 
                data[i].Sr_Analyst_ + '</td><td>' + 
                data[i].AM_ + '</td><td>' + 
                data[i].MANAGER_ + '</td><td>' + 
                data[i].SME_ + '</td><td>' + 
                data[i].Associate + '</td><td>' + 
                data[i].Analyst + '</td><td>' + 
                data[i].Sr_Analyst + '</td><td>' + 
                data[i].AM + '</td><td>' + 
                data[i].MANAGER + '</td><td>' + 
                data[i].SME + '</td><td>' + 
                data[i].T_BILLED + '</td><td>' + 
                data[i].T_BUFFER + '</td><td>' + 
                data[i].T_INVESTMENT + '</td><td>' + 
                data[i].BILLED_IND + '</td><td>' + 
                data[i].BUFFER_IND + '</td><td>' + 
                data[i].INVESTMENT_IND + '</td><td>' + 
                data[i].BILLED_USA + '</td><td>' + 
                data[i].BUFFER_USA + '</td><td>' + 
                data[i].INVESTMENT_USA + '</td></tr>');
                $('#sow_res_recom_table_data').append(row);
            }
            
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
        }  
    });  
}

