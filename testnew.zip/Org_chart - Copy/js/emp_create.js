function createEmpDetails(){
    let employee_id = parseInt($("#employee_id").val());
    let name = $("#name").val();
    let designation = $("#designation").val();
    let function_type = $("#function").val();
    let project_manager = $("#project_manager").val();
    let reporting_manager = $("#reporting_manager").val();
    let location = $("#location").val();
    let join_date = $("#join_date").val();
    let end_date = $("#end_date").val();
    if(end_date == ""){
        end_date = "0000-00-00";
    }
    let flag = parseInt($("#flag").val());
    let skills = $("#skills").val();
    var empCreateData = {
        "EMPLOYEE_ID":employee_id,
        "DETAILS": "[{\"EMPLOYEE_ID\":" +employee_id+
                    ",\"EMPLOYEE_NAME\": \""+name+
                    "\",\"JOIN_DATE\": \""+join_date+
                    "\",\"END_DATE\": \""+end_date+
                    "\",\"FLAG\": "+flag+
                    ",\"FUNCTION_\": \""+function_type+
                    "\",\"LOCATION_\": \""+location+
                    "\",\"DESIGNATION\": \""+designation+
                    "\",\"EMPLOYEE_CODE\": "+employee_id+
                    "}]"
        
    }    
    console.log("empCreateData - ",empCreateData);
    $.ajax({
        // url: "http://192.168.30.155:5000/addemployee",
        url : "https://rre-api.factspanapps.com:5000/addemployee",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        data: empCreateData,
        success:function(json){
            console.log("success");
            //window.location.href = 'employee.html';
            return false;
            //toastr.options.timeOut = 2000; // 2s
            //toastr.success('SOW Resource requirement created successfully');
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
            toastr.options.timeOut = 2000; // 2s
            toastr.success('Message error' + JSON.stringify(error));
        }  
    }); 
}