function getSowData() {
    var sowData = [];
    let endDate = "";
    let color = "";
    let probability = "";
    $.ajax({
        url: "https://rre-api.factspanapps.com:5000/app",
        // url: "http://localhost:5770/app",
        type: "POST",
        dataType: "json",
        crossDomain: true,
        format: "json",
        async: false,
        mode: 'no-cors',
        data : {
            query_type : "select",
            db_name : "rre_db",
            // db_name : "DEVELOP_DB",
            table_name : "SOW_MASTER_VIEW",
            //table_name : "SOW_MASTER",
            columns : "",
            filter : ""
        },
        beforeSend: function() {
          $('#loader').removeClass('hidden')
          console.log("loading started...");
        },
        success:function(data){
            jsonData = data
            console.log("Emp Data - ",jsonData);
            sowData = jsonData.data.Details;
            console.log("jsonData  - ",sowData);
            for (var i=0; i<sowData.length; i++) {
                // if(sowData[i].END_DATE == "0000-00-00"){
                //     endDate = "";
                // }else{
                //     endDate = convert(sowData[i].END_DATE);
                // }
                probability = sowData[i].PROBABILITY.replace("%","");
                // probability = sowData[i].PROBABILITY.replace(">","");
                // probability = sowData[i].PROBABILITY.replace("<","");
                // console.log("probability - "+probability);
                probability = probability.replace("%","");
                // console.log("probability 1 - "+probability);
                if(probability == "100"){
                    color = "white";
                }else if(probability == "70"){
                    color = "green";
                }else if(probability == "50"){
                    color = "yellow";
                }else if((probability == "30") || (probability == "20") || (probability == "10") || (probability == "0")){
                    color = "blue";
                }else if(probability == "Signed: 100"){
                  color = "white";
                }else if(probability == "Green: > 70"){
                  color = "green";
                }else if(probability == "Yellow: 30 to 70"){
                  color = "yellow";
                }else if(probability == "Blue: < 30"){
                  color = "blue";
                }
                //Yellow : 30% to 70%
                                
                var row = $('<tr class="'+color+'"><td>' + sowData[i].SOW_ID+ '</td><td>' + 
                sowData[i].SOW_CODE + '</td><td>' + 
                sowData[i].SOW_NAME + '</td><td>' + 
                sowData[i].CUSTOMER_ID + '</td><td>' + 
                convert(sowData[i].LEGAL_START_DATE) + '</td><td>' + 
                convert(sowData[i].LEGAL_END_DATE) + '</td><td>' + 
                convert(sowData[i].BILLING_START_DATE) + '</td><td>' + 
                convert(sowData[i].BILLING_END_DATE) + '</td><td>' + 
                convert(sowData[i].ACTUAL_START_DATE) + '</td><td>' + 
                convert(sowData[i].ACTUAL_END_DATE) + '</td><td>' + 
                sowData[i].PROJECT_DURATION+ '</td><td>' + 
                sowData[i].TOTAL_RESOURCES+ '</td><td>' + 
                sowData[i].ONSITE_RESOURCES+ '</td><td>' + 
                sowData[i].OFFSHORE_RESOURCES+ '</td><td>' + 
                sowData[i].PROBABILITY + '</td><td>' + 
                sowData[i].STATUS + '</td><td style="display:none">edited_sow</td><td style="display:none">form</td><td><button class="btn btn-info" id="sow_profile_details" style="margin: 10px;" onclick="getSowProfileData(this)">View All</button></td></tr>');
                $('#sow_emp_details').append(row);
                $('.green').attr('style', 'background-color: #b1eeb1 !important');
                $('.yellow').attr('style', 'background-color: #eae894 !important');
                $('.blue').attr('style', 'background-color: #9fbdf3 !important');
            }
            console.log("SOW data - ",row);
            $('#sow_emp_details').Tabledit({
                url: "https://rre-api.factspanapps.com:5000/app",
                // url: 'http://localhost:5770/app',
                type: "POST",
                dataType: "json",
                crossDomain: true,
                format: "json",
                async: false,
                mode: 'no-cors',
                // editButton: false,
                 deleteButton: false,
                // hideIdentifier: true,
                columns: {
                    identifier: [0, 'SOW_ID'],
                    editable: [[1, 'SOW_CODE'],[2, 'SOW_NAME'],[3,'ACCOUNT'],[4,'LEGAL_START_DATE'],[5,'LEGAL_END_DATE'],[6,'BILLING_START_DATE'],[7,'BILLING_END_DATE'],[8,'ACTUAL_START_DATE'],[9,'ACTUAL_END_DATE'],[10,'Period (Month)'],[11,'TOTAL_RESOURCES'],[12,'ONSITE_RESOURCES'],[13,'OFFSHORE_RESOURCES'],[14,'PROBABILITY'],[15,'Status'],[16,'query_type'],[17,'edited_sow']],
                    // edited_sow: editable
                },
                // data: {
                //   query_type : "select",
                //   db_name: "DEVELOP_DB",
                //   edited_sow: "["+ editable +"]"
                // },
                onDraw: function() {
                  // Select all inputs of second column and apply datepicker each of them
                  $('table tr td:nth-child(5) input').each(function() {
                    $(this).datepicker({
                      format: 'yyyy-mm-dd',
                      uiLibrary: 'bootstrap',
                      todayBtn: true,
                      todayHighlight: true
                    });
                  });
                  $('table tr td:nth-child(6) input').each(function() {
                    $(this).datepicker({
                      format: 'yyyy-mm-dd',
                      uiLibrary: 'bootstrap',
                      todayBtn: true,
                      todayHighlight: true
                    });
                  });
                  $('table tr td:nth-child(7) input').each(function() {
                    $(this).datepicker({
                      format: 'yyyy-mm-dd',
                      uiLibrary: 'bootstrap',
                      todayBtn: true,
                      todayHighlight: true
                    });
                  });
                  $('table tr td:nth-child(8) input').each(function() {
                    $(this).datepicker({
                      format: 'yyyy-mm-dd',
                      uiLibrary: 'bootstrap',
                      todayBtn: true,
                      todayHighlight: true
                    });
                  });
                  $('table tr td:nth-child(9) input').each(function() {
                    $(this).datepicker({
                      format: 'yyyy-mm-dd',
                      uiLibrary: 'bootstrap',
                      todayBtn: true,
                      todayHighlight: true
                    });
                  });
                  $('table tr td:nth-child(10) input').each(function() {
                    $(this).datepicker({
                      format: 'yyyy-mm-dd',
                      uiLibrary: 'bootstrap',
                      todayBtn: true,
                      todayHighlight: true
                    });
                  });
                },
                onSuccess: function(data, textStatus, jqXHR) {
                    console.log("data.action - "+data.action);
                    console.log('onSuccess(data, textStatus, jqXHR)');
                    console.log("data edit - ",data);
                    console.log("textStatus - "+textStatus);
                    console.log("jqXHR - ",jqXHR);
                }                
              });
              $('#sow_emp_details').dataTable();
              
        },
        error:function(error){
            console.log('message Error' + JSON.stringify(error));
        },
        complete: function(){
              $('#loader').addClass('hidden')
              console.log("loading ended...");
        },  
    });  
}

function getSowProfileData(obj) {
  var sow_id = $(obj).closest('tr').children('td:eq(0)').text();
  console.log("sow_id - "+sow_id);
  var sowDataProfile = [];
  let endDate = "";
  var local_sow_profile_data = "";
  $("body").addClass("loading"); 
  $.ajax({
      url: "https://rre-api.factspanapps.com:5000/app",
      // url : "http://localhost:5770/app",
      type: "POST",
      dataType: "json",
      crossDomain: true,
      format: "json",
      async: false,
      mode: 'no-cors',
      data : {
          query_type : "select",
          // db_name : "rre_db",
          db_name : "DEVELOP_DB",
          table_name : "SOW_SKILL_REQUIREMENT",
          columns : "",
          filter : "SOW_ID = '"+sow_id+"'"
      },
      success:function(data){
          jsonData = data
          sowDataProfile = jsonData.data.Details;
          console.log("Sow Profile - ",sowDataProfile);
          if (typeof(Storage) !== "undefined") {
              // Store
              localStorage.setItem("sow_profile_id_data", JSON.stringify(sowDataProfile));
              localStorage.setItem("sow_id_data", sow_id);
              // Retrieve
              local_sow_profile_data = localStorage.getItem("sow_profile_id_data");
          } else {
          document.getElementById("result").innerHTML = "Sorry, your browser does not support Web Storage...";
          }
          console.log("local_sow_profile_data - ",local_sow_profile_data);
          window.location.href = 'sowProfileDetails.html';
      },
      error:function(error){
          console.log('message Error' + JSON.stringify(error));
      }  
  });  
}

function convert(str) {
  if(str == null){
    return "";
  }else if(str == "0000-00-00"){
    return "";
  }
  else{
    var date = new Date(str),
      mnth = ("0" + (date.getMonth() + 1)).slice(-2),
      day = ("0" + date.getDate()).slice(-2);
    return [date.getFullYear(), mnth, day].join("-");
  }
  }
  console.log(convert("Mon, 11 Nov 2013 00:00:00 GMT"))